#include <iostream>
#include <string>

using namespace std;

const int MAX_PLATFORMS = 3;
const int MAX_GAMES = 4;

class Game {
private:
    string name;
    string size;
    string releaseDate;
    string description;
    string platforms[MAX_PLATFORMS];
    string minRAM;
    string minGPU;
    string minProcessor;
    string additionalInfo;

public:
    Game(string n, string s, string r, string d, string p[], string ram, string gpu, string proc, string info) {
        name = n;
        size = s;
        releaseDate = r;
        description = d;
        for (int i = 0; i < MAX_PLATFORMS; i++) {
            platforms[i] = p[i];
        }
        minRAM = ram;
        minGPU = gpu;
        minProcessor = proc;
        additionalInfo = info;
    }

    void showDetails() const {
        cout << "\nGame: " << name << " (" << size << ")" << endl;
        cout << "Release Date: " << releaseDate << endl;
        cout << "Description: " << description << endl;
        cout << "Available on: ";
        for (const auto& platform : platforms) {
            if (!platform.empty()) {
                cout << platform << " ";
            }
        }
        cout << "\nMinimum Requirements:" << endl;
        cout << "RAM: " << minRAM << endl;
        cout << "GPU: " << minGPU << endl;
        cout << "Processor: " << minProcessor << endl;
        cout << "Additional Information: " << additionalInfo << endl;
    }

    string getName() const {
        return name;
    }
};

class GameLibrary {
private:
    Game* games[MAX_GAMES];
    int gameCount;

public:
    GameLibrary() : gameCount(0) {}

    void addGame(Game* game) {
        if (gameCount < MAX_GAMES) {
            games[gameCount++] = game;
        }
    }

    void showGames() const {
        for (int i = 0; i < gameCount; i++) {
            cout << i + 1 << ". " << games[i]->getName() << endl;
        }
    }

    void showGameDetails(int index) const {
        if (index >= 0 && index < gameCount) {
            games[index]->showDetails();
        } else {
            cout << "Invalid choice!" << endl;
        }
    }

    int getGameCount() const {
        return gameCount;
    }
};

int main() {
    GameLibrary library;

    // Action Games
    string actionPlatforms1[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("Grand Theft Auto V", "80GB", "Sept 2013", "Open-world action-adventure game.", actionPlatforms1, "8GB", "GTX 660", "Intel i5", "Multiplayer supported"));

    string actionPlatforms2[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("Call of Duty: Modern Warfare", "175GB", "Oct 2019", "First-person shooter.", actionPlatforms2, "8GB", "GTX 670", "Intel i3", "Multiplayer supported"));

    string actionPlatforms3[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("Fortnite", "40GB", "July 2017", "Battle royale game.", actionPlatforms3, "4GB", "Intel HD 4000", "Intel i3", "Cross-platform play supported"));

    string actionPlatforms4[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("Apex Legends", "50GB", "Feb 2019", "Battle royale shooter.", actionPlatforms4, "6GB", "GTX 970", "Intel i5", "Multiplayer battle royale"));

    // Adventure Games
    string adventurePlatforms1[] = {"Switch"};
    library.addGame(new Game("The Legend of Zelda: Breath of the Wild", "14GB", "March 2017", "Open-world adventure game.", adventurePlatforms1, "4GB", "Custom hardware", "Custom hardware", "Exploration and puzzle-solving"));

    string adventurePlatforms2[] = {"PS4", "PS5"};
    library.addGame(new Game("Uncharted 4: A Thief's End", "55GB", "May 2016", "Action-adventure game.", adventurePlatforms2, "8GB", "GTX 1060", "Intel i5", "Cinematic narrative-driven adventure"));

    string adventurePlatforms3[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("Tomb Raider (2013)", "12GB", "March 2013", "Action-adventure game.", adventurePlatforms3, "4GB", "GTX 480", "Intel i3", "Reboot of the iconic franchise"));

    string adventurePlatforms4[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("Red Dead Redemption 2", "150GB", "Oct 2018", "Open-world adventure game.", adventurePlatforms4, "8GB", "GTX 770", "Intel i5", "Wild West-themed adventure"));

    // Racing Games
    string racingPlatforms1[] = {"Windows", "Xbox One"};
    library.addGame(new Game("Forza Horizon 4", "80GB", "Sept 2018", "Open-world racing game.", racingPlatforms1, "8GB", "GTX 970", "Intel i5", "Dynamic weather system"));

    string racingPlatforms2[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("Need for Speed: Heat", "50GB", "Nov 2019", "Street racing game.", racingPlatforms2, "8GB", "GTX 760", "Intel i5", "Day and night cycle"));

    string racingPlatforms3[] = {"Windows", "PS4", "PS5"};
    library.addGame(new Game("F1 2021", "80GB", "July 2021", "Formula 1 racing game.", racingPlatforms3, "16GB", "GTX 1660", "Intel i5", "Story mode and multiplayer"));

    string racingPlatforms4[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("Dirt 5", "60GB", "Nov 2020", "Off-road racing game.", racingPlatforms4, "8GB", "GTX 970", "Intel i5", "Dynamic weather and multiplayer"));

    // Role-Playing Games (RPGs)
    string rpgPlatforms1[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("The Witcher 3: Wild Hunt", "50GB", "May 2015", "Open-world RPG.", rpgPlatforms1, "6GB", "GTX 660", "Intel i5", "Multiple endings"));

    string rpgPlatforms2[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("Elden Ring", "60GB", "Feb 2022", "Action RPG set in a fantasy world.", rpgPlatforms2, "12GB", "GTX 1060", "Intel i7", "Open-world exploration"));

    string rpgPlatforms3[] = {"Windows", "PS4", "Xbox One"};
    library.addGame(new Game("Cyberpunk 2077", "70GB", "Dec 2020", "Futuristic open-world RPG.", rpgPlatforms3, "8GB", "GTX 780", "Intel i5", "First-person RPG"));

    string rpgPlatforms4[] = {"PS4", "PS5", "Switch"};
    library.addGame(new Game("Persona 5 Royal", "30GB", "Oct 2019", "Turn-based RPG with a strong narrative.", rpgPlatforms4, "4GB", "Intel HD Graphics", "Intel i3", "Enhanced version with new content"));

    int genreChoice;
    cout << "Select a genre:" << endl;
    cout << "1. Action\n2. Adventure\n3. Racing\n4. Role-Playing Games (RPGs)" << endl;
    cin >> genreChoice;

    switch (genreChoice) {
        case 1:
            cout << "Action Games:" << endl;
            library.showGames();
            break;
        case 2:
            cout << "Adventure Games:" << endl;
            library.showGames();
            break;
        case 3:
            cout << "Racing Games:" << endl;
            library.showGames();
            break;
        case 4:
            cout << "Role-Playing Games (RPGs):" << endl;
            library.showGames();
            break;
        default:
            cout << "Invalid genre choice!" << endl;
            break;
    }

    cout << "Select a game (1-" << library.getGameCount() << "): ";
    int gameChoice;
    cin >> gameChoice;

    if (gameChoice >= 1 && gameChoice <= library.getGameCount()) {
        library.showGameDetails(gameChoice - 1);
    } else {
        cout << "Invalid choice!" << endl;
    }

    return 0;
}
